﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyApp
{
    class NAlign
    {
        double  pattern_Q1, pattern_Q2, pattern_Q3, pattern_Q4;
        bool    training_flag = false;

        public NAlign()
        {
            pattern_Q1 = pattern_Q2 = pattern_Q3 = pattern_Q4 = 0;
        }

        /**************************訓練樣板***********************************************/
        public bool Training(int[] Sx, int[] Sy, int num)
        {
            if (ChainToIMI(Sx, Sy, num, ref pattern_Q1, ref pattern_Q2, ref pattern_Q3, ref pattern_Q4))
            {
                training_flag = true;

                return true;
            }
            else
                return false;
            
        }

        /**************************最小距離邊界矩分類器***********************************************/
        public double MinDistance(int[] Sx, int[] Sy, int num)
        {
            if (!training_flag) return -1;

            double distance;
            double[] dp = new double[4];

            double Q1, Q2, Q3, Q4;

            Q1 = Q2 = Q3 = Q4 = 0;
            if (ChainToIMI(Sx, Sy, num, ref Q1, ref Q2, ref Q3, ref Q4))
            {
                dp[0] = (pattern_Q1 - Q1) / pattern_Q1;
                dp[1] = (pattern_Q2 - Q2) / pattern_Q2;
                dp[2] = (pattern_Q3 - Q3) / pattern_Q3;
                dp[3] = (pattern_Q4 - Q4) / pattern_Q4;

                distance = Math.Sqrt(dp[0] * dp[0] + dp[1] * dp[1] + dp[2] * dp[2] + dp[3] * dp[3]);

                return distance;
            }
            else
                return -1;      
        }

        /**************************輪廓座標轉不變矩特徵********************************************************/
        private bool ChainToIMI(int[] Sx, int[] Sy, int num, ref double Q1, ref double Q2, ref double Q3, ref double Q4)
        {
            double u11, u02, u20, u12, u21, u03, u30;
            double a2, a25;
            double t11, t20, t02, t30, t03, t12, t21;

            double Cx = 0, Cy = 0;
            for (int i = 0; i < num; i++)
            {
                Cx += Sx[i];
                Cy += Sy[i];
            }

            Cx /= num;
            Cy /= num;

            u11 = u02 = u20 = u12 = u21 = u03 = u30 = 0;

            double Rx = 0, Ry = 0;
            for (int i = 0; i < num; i++)
            {
                Rx = Sx[i] - Cx;
                Ry = Sy[i] - Cy;

                u11 += Rx * Ry; u20 += Rx * Rx;
                u02 += Ry * Ry; u21 += Rx * Rx * Ry;
                u12 += Rx * Ry * Ry; u30 += Rx * Rx * Rx;
                u03 += Ry * Ry * Ry;
            }

            a2 = (double)(num * num);
            a25 = (double)Math.Pow(num, 2.5);

            t11 = u11 * 100 / a2; t20 = u20 * 100 / a2;
            t02 = u02 * 100 / a2; t30 = u30 * 100 / a25;
            t03 = u03 * 100 / a25; t12 = u12 * 100 / a25;
            t21 = u21 * 100 / a25;


            Q1 = (t20 + t02);
            Q2 = (t20 - t02) * (t20 - t02) + 4 * t11 * t11;
            Q3 = (t30 - 3 * t12) * (t30 - 3 * t12) + (t03 - 3 * t21) * (t03 - 3 * t21);
            Q4 = (t30 + t12) * (t30 + t12) + (t03 + t21) * (t03 + t21);

            return true;
        }

    }
}
