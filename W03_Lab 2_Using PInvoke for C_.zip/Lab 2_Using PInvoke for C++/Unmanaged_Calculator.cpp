#include "pch.h"
#include "Unmanaged_Calculator.h"

int Unmanaged_Calculator::Add(int a, int b)
{
	return a + b;
}
