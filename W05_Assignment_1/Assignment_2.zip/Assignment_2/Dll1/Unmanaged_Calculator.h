#pragma once

class _declspec(dllexport) Unmanaged_Calculator
{
public:

	Unmanaged_Calculator() {};

	int Add(int a, int b);
};





