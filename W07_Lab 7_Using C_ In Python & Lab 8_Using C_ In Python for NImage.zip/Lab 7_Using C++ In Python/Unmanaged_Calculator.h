#pragma once
#include <windows.h>

class Unmanaged_Calculator
{
	public:

		Unmanaged_Calculator() {};

		int		Add(int a, int b);

};



