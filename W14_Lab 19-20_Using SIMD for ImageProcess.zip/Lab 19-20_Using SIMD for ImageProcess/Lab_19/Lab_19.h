	bool	Inverse_SIMD(NImage *pImg);
	bool	SingleThresholding_SIMD(NImage *pImg, int threshold);