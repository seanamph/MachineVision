	bool	Subtract(NImage *pSrcImg, NImage *pRefImg);
	bool	BitwiseXOR(NImage *pSrcImg, NImage *pRefImg);